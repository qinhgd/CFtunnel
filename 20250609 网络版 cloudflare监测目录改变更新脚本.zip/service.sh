#!/system/bin/sh
# v2.1: 更新日志函数，确保启动时的日志记录准确。

# === 配置环境 ===
MODDIR="$(cd "$(dirname "$0")"; pwd)"
CORE_DIR="$MODDIR/core"
LOG_DIR="$MODDIR/logs"
WATCHDOG_SCRIPT="$MODDIR/watchdog.sh"
START_LOGFILE="$LOG_DIR/cloudflared_start.log" # For initial startup logs

# === 准备工作 ===
# 确保必要的子目录存在
mkdir -p "$CORE_DIR"
mkdir -p "$LOG_DIR"

# 定义 log_start 函数 (确保与 service.sh 和 watchdog.sh 中定义一致)
log_start() {
    # 确保日志目录存在 (即使在函数内部，也再次检查以防万一)
    mkdir -p "$LOG_DIR"
    echo "$(date "+%Y-%m-%d %H:%M:%S") [START] $1" >> "$START_LOGFILE"
}

# 清理旧的启动日志 (通常只在模块首次启动或更新时清理)
# 在这里清理可能会丢失之前 service.sh 写入的日志，如果 service.sh 是由 watchdog 启动的
# 建议这个脚本只追加日志，除非你确定每次启动都希望清空日志。
# 如果不清理，可以将下面这行注释掉。
rm -f "$START_LOGFILE"

log_start "脚本开始执行 (Launcher 模式 v2.1) - 等待系统启动完成..."

# 等待系统完全启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

log_start "系统启动完成，继续执行..."

# === 启动监控服务 ===
log_start "正在检查 Watchdog 监控服务状态..."
if pgrep -f "$WATCHDOG_SCRIPT" >/dev/null; then
    log_start "Watchdog 监控服务已在运行。"
    exit 0 # 如果已运行，则无需再次启动
fi

log_start "正在后台启动 Watchdog 监控服务..."
# 确保 watchdog 脚本有执行权限
chmod +x "$WATCHDOG_SCRIPT"
# 使用 nohup 将 watchdog 脚本放到后台运行，脱离当前会话
nohup sh "$WATCHDOG_SCRIPT" >/dev/null 2>&1 &

sleep 2 # 给 watchdog 脚本一些时间启动

if pgrep -f "$WATCHDOG_SCRIPT" >/dev/null; then
    log_start "Watchdog 监控服务启动成功。"
else
    log_start "错误: Watchdog 监控服务启动失败。"
fi

exit 0