#!/system/bin/sh

# SCRIPT VERSION: DNSMASQ_WORKAROUND 2.4
# v2.4: 在脚本成功执行完毕后，添加完成提示信息，告知用户可关闭终端。

# === 配置 ===
MODDIR="$(cd "$(dirname "$0")"; pwd)"
# 新增: 定义核心文件和日志文件的目录
CORE_DIR="$MODDIR/core"
LOG_DIR="$MODDIR/logs"

# 更新: 所有文件路径都指向新的子目录
CLOUDFLARED="$CORE_DIR/cloudflared"
TOKEN_FILE="$CORE_DIR/token"
DNSMASQ_PID_FILE="$LOG_DIR/dnsmasq.pid"
RUN_LOGFILE="$LOG_DIR/cloudflared_run.log"
START_LOGFILE="$LOG_DIR/cloudflared_start.log"
WATCHDOG_SCRIPT="$MODDIR/watchdog.sh" # 新增: watchdog 脚本路径

# === 脚本函数 ===
log_start() {
    # 确保日志目录存在
    mkdir -p "$LOG_DIR"
    echo "$(date "+%Y-%m-%d %H:%M:%S") [START] $1" >> "$START_LOGFILE"
}

# 函数来检查端口是否被监听
is_port_in_use() {
    PORT=$1
    # 使用 netstat 检查端口是否被监听 (TCP 或 UDP)
    # 兼容 BusyBox grep: 使用字面空格
    if netstat -tuln | grep -q ":$PORT " ; then
        return 0 # 端口正在被使用
    else
        return 1 # 端口未被使用
    fi
}


# 清理函数，用于脚本退出时确保 dnsmasq 被关闭
cleanup() {
    if [ -f "$DNSMASQ_PID_FILE" ]; then
        log_start "正在停止临时的 dnsmasq 服务..."
        # 确保 pid 文件中的 PID 是有效的，且属于 dnsmasq
        PID=$(cat "$DNSMASQ_PID_FILE" 2>/dev/null)
        if [ -n "$PID" ] && ps -p "$PID" | grep -q "dnsmasq"; then
            kill "$PID" >/dev/null 2>&1
            log_start "dnsmasq ($PID) 已停止。"
        else
            log_start "未找到运行中的 dnsmasq 进程或 PID 无效。"
        fi
        rm -f "$DNSMASQ_PID_FILE"
    fi
}

# === 预备工作 ===
# 确保必要的子目录存在
mkdir -p "$CORE_DIR"
mkdir -p "$LOG_DIR"

# 清理旧的启动日志
rm -f "$START_LOGFILE"

log_start "脚本开始执行 (Dnsmasq 模式 v2.4)..."
chmod 755 "$CLOUDFLARED"

# 注册清理函数，在脚本退出时自动执行
trap cleanup EXIT

# 检查依赖
# 这里改为检查 dnsmasq 是否存在于 PATH 中，或者使用特定路径
local DNSMASQ_BIN="" # 声明为局部变量以避免冲突
if ! command -v dnsmasq >/dev/null; then
    # 如果 dnsmasq 不在 PATH 中，尝试检查 CORE_DIR
    if [ -f "$CORE_DIR/dnsmasq" ]; then
        DNSMASQ_BIN="$CORE_DIR/dnsmasq"
        chmod 755 "$DNSMASQ_BIN"
    else
        log_start "错误: 找不到 dnsmasq 命令。此脚本无法运行。"
        exit 1
    fi
else
    # 如果 dnsmasq 在 PATH 中，直接使用命令名
    DNSMASQ_BIN="dnsmasq"
fi


if [ ! -f "$TOKEN_FILE" ]; then
    log_start "错误: Token 文件未找到 ($TOKEN_FILE)"
    exit 1
fi
if pgrep -f "$CLOUDFLARED tunnel" >/dev/null; then
    log_start "cloudflared 已经在运行中。"
    echo ""
    echo "======================================"
    echo "Cloudflared 隧道已在后台运行并受监控。"
    echo "您可以安全地关闭此终端窗口。"
    echo "======================================"
    exit 0
fi

# === 核心启动流程 ===
# 1. 启动临时 DNS 服务器 (只有在端口 53 未被占用时)
log_start "正在检查端口 53 (DNS 服务)..."
if is_port_in_use 53; then
    log_start "端口 53 正在被其他服务监听，跳过启动 dnsmasq。"
else
    log_start "端口 53 未被占用，尝试启动临时的 dnsmasq 服务..."
    # 你的 dnsmasq 命令，确保其监听 127.0.0.1 或 ::1 且使用端口 53
    # 使用 DNSMASQ_BIN 变量来启动 dnsmasq
    nohup "$DNSMASQ_BIN" --listen-address=127.0.0.1,::1 --port=53 --no-resolv --server=1.1.1.1 --pid-file="$DNSMASQ_PID_FILE" >/dev/null 2>&1 &
    
    # 检查 dnsmasq 是否成功启动
    sleep 1
    if [ ! -f "$DNSMASQ_PID_FILE" ] || ! pgrep -f "$DNSMASQ_BIN" | grep -q "$(cat "$DNSMASQ_PID_FILE" 2>/dev/null)"; then
        log_start "错误: 启动 dnsmasq 失败。"
        exit 1
    fi
    log_start "临时的 dnsmasq 服务已启动。"
fi


# 2. 启动 cloudflared
TOKEN=$(tr -d '[:space:]' < "$TOKEN_FILE")
log_start "准备启动 cloudflared..."
nohup "$CLOUDFLARED" \
    tunnel \
    --loglevel info \
    --logfile "$RUN_LOGFILE" \
    run --token "$TOKEN" >/dev/null 2>&1 &

# 3. 等待并验证 cloudflared
sleep 5
if pgrep -f "$CLOUDFLARED tunnel" >/dev/null; then
    log_start "cloudflared 启动成功。"
    log_start "cloudflared 已在后台运行。"
else
    log_start "错误: cloudflared 启动失败。"
    exit 1
fi

# --- 4. 启动 Watchdog 脚本 ---
log_start "启动 Watchdog 监控脚本..."
if [ -f "$WATCHDOG_SCRIPT" ]; then
    nohup sh "$WATCHDOG_SCRIPT" >/dev/null 2>&1 &
    log_start "Watchdog 脚本已在后台启动。"
else
    log_start "警告: Watchdog 脚本不存在 ($WATCHDOG_SCRIPT)。无法启动监控。"
fi

# === 最终完成提示 ===
echo ""
echo "======================================"
echo "Cloudflared 隧道已在后台运行并受监控。"
echo "您可以安全地关闭此终端窗口。"
echo "======================================"
# 脚本成功执行到末尾，trap 'cleanup' EXIT 会自动执行
exit 0