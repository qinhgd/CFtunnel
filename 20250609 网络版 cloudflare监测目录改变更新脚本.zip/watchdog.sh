#!/system/bin/sh
# v2.3: 优化 dnsmasq 清理逻辑，在 cloudflared 成功重启后立即关闭 dnsmasq。

# === 配置环境 ===
MODDIR="$(cd "$(dirname "$0")"; pwd)"
CORE_DIR="$MODDIR/core"
LOG_DIR="$MODDIR/logs"

# 定义文件路径
CLOUDFLARED="$CORE_DIR/cloudflared"
TOKEN_FILE="$CORE_DIR/token"
DNSMASQ_PID_FILE="$LOG_DIR/dnsmasq.pid"
RUN_LOGFILE="$LOG_DIR/cloudflared_run.log"
WATCHDOG_LOGFILE="$LOG_DIR/watchdog.log"
MAX_LOG_SIZE=3145728 # 3MB

# === 函数定义 ===
log_watchdog() {
    # 确保日志目录存在
    mkdir -p "$LOG_DIR"
    # 日志文件大小管理
    if [ -f "$WATCHDOG_LOGFILE" ] && [ "$(stat -c %s "$WATCHDOG_LOGFILE")" -gt "$MAX_LOG_SIZE" ]; then
        echo "$(date "+%Y-%m-%d %H:%M:%S") [WATCHDOG] 日志文件超过3MB，自动收缩..." > "$WATCHDOG_LOGFILE.tmp"
        tail -n 100 "$WATCHDOG_LOGFILE" >> "$WATCHDOG_LOGFILE.tmp"
        mv "$WATCHDOG_LOGFILE.tmp" "$WATCHDOG_LOGFILE"
    fi
    echo "$(date "+%Y-%m-%d %H:%M:%S") [WATCHDOG] $1" >> "$WATCHDOG_LOGFILE"
}

# 函数来检查端口是否被监听 (与 service.sh 保持一致)
is_port_in_use() {
    PORT=$1
    # 使用 netstat 检查端口是否被监听 (TCP 或 UDP)
    # 确保兼容 BusyBox grep: 使用字面空格
    if netstat -tuln | grep -q ":$PORT " ; then
        return 0 # 端口正在被使用
    else
        return 1 # 端口未被使用
    fi
}

# 清理 dnsmasq 函数，用于脚本退出或重启 cloudflared 后调用
cleanup_dnsmasq_instance() {
    log_watchdog "正在执行 dnsmasq 实例清理..."
    if [ -f "$DNSMASQ_PID_FILE" ]; then
        PID=$(cat "$DNSMASQ_PID_FILE" 2>/dev/null)
        if [ -n "$PID" ] && ps -p "$PID" | grep -q "dnsmasq"; then
            log_watchdog "正在停止临时的 dnsmasq 服务 (PID: $PID)..."
            kill "$PID" >/dev/null 2>&1
            log_watchdog "dnsmasq ($PID) 已停止。"
        else
            log_watchdog "未找到运行中的 dnsmasq 进程或 PID 无效。"
        fi
        rm -f "$DNSMASQ_PID_FILE"
    else
        log_watchdog "dnsmasq PID 文件不存在，无需停止 dnsmasq。"
    fi
}


start_cloudflared() {
    log_watchdog "检测到 cloudflared 未运行，正在尝试重启..."
    
    if [ ! -f "$TOKEN_FILE" ]; then
        log_watchdog "错误: 找不到 Token 文件: $TOKEN_FILE"
        return 1
    fi
    
    # 检查 dnsmasq 是否存在于 PATH 中，或者使用特定路径
    local DNSMASQ_BIN=""
    if ! command -v dnsmasq >/dev/null; then
        if [ -f "$CORE_DIR/dnsmasq" ]; then
            DNSMASQ_BIN="$CORE_DIR/dnsmasq"
            chmod 755 "$DNSMASQ_BIN"
        else
            log_watchdog "错误: 找不到 dnsmasq 命令。跳过 dnsmasq 启动。"
            # 即使 dnsmasq 无法启动，我们仍然尝试启动 cloudflared
        fi
    else
        DNSMASQ_BIN="dnsmasq"
    fi

    # 仅在端口 53 未被占用且 dnsmasq 可用时启动 dnsmasq
    local DNSMASQ_STARTED_BY_US=0 # 标志位，记录 dnsmasq 是否由当前 start_cloudflared 启动
    if [ -n "$DNSMASQ_BIN" ]; then
        if is_port_in_use 53; then
            log_watchdog "端口 53 正在被其他服务监听，跳过启动 dnsmasq。"
        else
            log_watchdog "端口 53 未被占用，正在启动临时的 dnsmasq 服务..."
            nohup "$DNSMASQ_BIN" --listen-address=127.0.0.1,::1 --port=53 --no-resolv --server=1.1.1.1 --pid-file="$DNSMASQ_PID_FILE" >/dev/null 2>&1 &
            sleep 1
            if [ ! -f "$DNSMASQ_PID_FILE" ] || ! pgrep -f "$DNSMASQ_BIN" | grep -q "$(cat "$DNSMASQ_PID_FILE" 2>/dev/null)"; then
                log_watchdog "错误: 启动 dnsmasq 失败。"
            else
                log_watchdog "临时的 dnsmasq 服务已启动。"
                DNSMASQ_STARTED_BY_US=1 # 标记 dnsmasq 已被我们启动
            fi
        fi
    else
        log_watchdog "dnsmasq 命令不可用，跳过 dnsmasq 启动。"
    fi

    TOKEN=$(tr -d '[:space:]' < "$TOKEN_FILE")
    log_watchdog "准备启动 cloudflared..."
    nohup "$CLOUDFLARED" tunnel --loglevel info --logfile "$RUN_LOGFILE" run --token "$TOKEN" >/dev/null 2>&1 &
    sleep 5

    if pgrep -f "$CLOUDFLARED tunnel" >/dev/null; then
        log_watchdog "cloudflared 重启成功。"
        # cloudflared 成功启动后，立即清理 dnsmasq 实例
        if [ "$DNSMASQ_STARTED_BY_US" -eq 1 ]; then
            cleanup_dnsmasq_instance
        else
            log_watchdog "dnsmasq 未由本次启动，无需关闭。"
        fi
    else
        log_watchdog "错误: cloudflared 重启失败。"
        # 如果 cloudflared 启动失败，则清理 dnsmasq (无论是否由我们启动)
        log_watchdog "cloudflared 启动失败，正在清理 dnsmasq..."
        cleanup_dnsmasq_instance
    fi
}

# === 主循环 ===
# === 预备工作 (确保在主循环开始前执行一次) ===
# 确保必要的子目录存在
mkdir -p "$CORE_DIR"
mkdir -p "$LOG_DIR"

log_watchdog "监控服务已启动 (v2.3)。"

# 注册清理函数，在脚本退出时自动执行
trap cleanup_dnsmasq_instance EXIT

while true; do
    if ! pgrep -f "$CLOUDFLARED tunnel" >/dev/null; then
        log_watchdog "cloudflared 进程未运行。"
        start_cloudflared
    fi
    sleep 60
done