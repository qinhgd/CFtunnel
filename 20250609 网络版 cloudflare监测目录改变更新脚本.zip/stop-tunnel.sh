#!/system/bin/sh
# v2.0: Re-structured directories

MODDIR="$(cd "$(dirname "$0")"; pwd)"
CORE_DIR="$MODDIR/core"
LOG_DIR="$MODDIR/logs"
CLOUDFLARED_PROCESS_PATH="$CORE_DIR/cloudflared"
WATCHDOG_SCRIPT="$MODDIR/watchdog.sh"
DNSMASQ_PID_FILE="$LOG_DIR/dnsmasq.pid"

echo "正在尝试关闭所有相关服务 (v2.0)..."
echo "============================="

echo "-> 正在停止 Watchdog 监控..."
if pgrep -f "$WATCHDOG_SCRIPT" >/dev/null; then
    pkill -f "$WATCHDOG_SCRIPT"
    echo "   Watchdog 已关闭。"
else
    echo "   Watchdog 未在运行。"
fi

echo "-> 正在停止 cloudflared 隧道..."
if pgrep -f "$CLOUDFLARED_PROCESS_PATH tunnel" >/dev/null; then
    pkill -f "$CLOUDFLARED_PROCESS_PATH tunnel"
    echo "   cloudflared 已关闭。"
else
    echo "   cloudflared 未在运行。"
fi

echo "-> 正在清理临时的 dnsmasq 服务..."
if [ -f "$DNSMASQ_PID_FILE" ]; then
    kill "$(cat "$DNSMASQ_PID_FILE")" >/dev/null 2>&1
    rm -f "$DNSMASQ_PID_FILE"
    echo "   通过 PID 文件关闭了 dnsmasq。"
elif pgrep -f "dnsmasq --listen-address=127.0.0.1,::1" >/dev/null; then
    pkill -f "dnsmasq --listen-address=1.1.1.1"
    echo "   通过进程名关闭了 dnsmasq。"
else
    echo "   dnsmasq 未在运行。"
fi

echo "============================="
echo "所有服务已清理完毕。"

exit 0