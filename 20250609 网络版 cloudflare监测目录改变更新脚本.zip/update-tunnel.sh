#!/system/bin/sh
# v2.7: 增加对 cloudflared 二进制文件存在的检查，以处理文件缺失但版本文件存在的情况。

set -e

# === 配置环境 ===
MODDIR="$(cd "$(dirname "$0")"; pwd)"
CORE_DIR="$MODDIR/core"
CLOUDFLARED_BIN="$CORE_DIR/cloudflared"
VERSION_FILE="$CORE_DIR/version.txt" # 本地版本号文件
STOP_SCRIPT="$MODDIR/stop-tunnel.sh"
START_SCRIPT="$MODDIR/service.sh"
TEMP_FILE="$MODDIR/cloudflared.new"
DOWNLOAD_BASE_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-" # URL前缀

echo "Cloudflared 更新程序 (v2.7)"
echo "======================"

mkdir -p "$CORE_DIR"

if ! command -v curl >/dev/null; then
    echo "错误: 找不到 'curl' 命令。请确保您的系统安装了 curl。"
    exit 1
fi

if ! command -v grep >/dev/null; then
    echo "错误: 找不到 'grep' 命令。请确保您的系统安装了 grep。"
    exit 1
fi

if ! command -v sed >/dev/null; then
    echo "错误: 找不到 'sed' 命令。请确保您的系统安装了 sed。"
    exit 1
fi

echo "[1/7] 正在检测设备架构..."
CPU_ABI=$(getprop ro.product.cpu.abi)
case $CPU_ABI in
    arm64-v8a) ARCH="arm64";;
    armeabi-v7a) ARCH="arm";;
    x86_64) ARCH="amd64";;
    x86) ARCH="386";;
    *) echo "错误: 无法识别的CPU架构: $CPU_ABI"; exit 1;;
esac
echo " -> 检测到架构: $ARCH"

# --- 获取当前版本号 (优先从本地文件，其次从二进制，最后“未安装”) ---
CURRENT_VERSION="未安装"
BINARY_MISSING=0 # 标志位：0=存在，1=缺失

if [ -f "$VERSION_FILE" ]; then
    CURRENT_VERSION=$(cat "$VERSION_FILE" | sed 's/\r//g') # 读取并去除回车符
    echo " -> 检测到本地版本文件: $CURRENT_VERSION"
    # 额外检查二进制文件是否存在
    if [ ! -f "$CLOUDFLARED_BIN" ]; then
        echo " -> 警告: 本地版本文件存在，但 cloudflared 二进制文件缺失！将强制下载最新版本。"
        BINARY_MISSING=1
        # 为了强制下载，我们将当前版本设置为一个肯定不匹配最新线上的值
        CURRENT_VERSION="BINARY_MISSING_FORCE_UPDATE"
    fi
elif [ -f "$CLOUDFLARED_BIN" ]; then
    # 如果本地文件不存在，尝试从二进制文件获取，并保存到本地文件
    VERSION_OUTPUT=$("$CLOUDFLARED_BIN" --version 2>/dev/null | head -n 1)
    if echo "$VERSION_OUTPUT" | grep -q "version"; then
        PARSED_VERSION=$(echo "$VERSION_OUTPUT" | awk '{print $3}' | sed 's/(build//g' | sed 's/)//g' | sed 's/\r//g')
        if echo "$PARSED_VERSION" | grep -q "UTC"; then
            PARSED_VERSION=$(echo "$VERSION_OUTPUT" | awk '{print $(NF-2)}' | sed 's/(build//g' | sed 's/)//g' | sed 's/\r//g')
        fi
        PARSED_VERSION=$(echo "$PARSED_VERSION" | sed 's/(build.*//' | sed 's/\r//g')
        
        if [ -n "$PARSED_VERSION" ] && ! echo "$PARSED_VERSION" | grep -q "无法获取"; then
            CURRENT_VERSION="$PARSED_VERSION"
            echo "$CURRENT_VERSION" > "$VERSION_FILE" # 保存到本地文件
            echo " -> 从二进制获取并保存到本地: $CURRENT_VERSION"
        else
            echo " -> 无法从二进制文件获取有效版本。"
        fi
    fi
else
    echo " -> cloudflared 未安装。"
fi
echo " -> 当前版本: $CURRENT_VERSION"

echo "[2/7] 正在获取最新版本信息..."
# 使用兼容 BusyBox 的 grep 和 sed 来提取 tag_name
LATEST_TAG=$(curl -sL "https://api.github.com/repos/cloudflare/cloudflared/releases/latest" | grep "tag_name" | head -n 1 | sed -e 's/.*"tag_name": "\(.*\)".*/\1/' | sed 's/\r//g')

if [ -z "$LATEST_TAG" ]; then
    echo "错误: 无法获取最新版本信息。请检查网络或 GitHub API 访问。"
    exit 1
fi
echo " -> 最新线上版本: $LATEST_TAG"

# 比较版本号，如果当前版本与最新版本相同，则不下载
# 处理版本号可能包含 'v' 前缀的情况
COMPARE_CURRENT_VERSION=$(echo "$CURRENT_VERSION" | sed 's/^v//' | sed 's/\r//g')
COMPARE_LATEST_TAG=$(echo "$LATEST_TAG" | sed 's/^v//' | sed 's/\r//g')

# 核心逻辑：如果当前版本与最新线上版本相同，且二进制文件存在，则跳过下载
# 否则（版本不同，或二进制文件缺失），则继续下载流程
if [ "$COMPARE_CURRENT_VERSION" = "$COMPARE_LATEST_TAG" ] && [ "$BINARY_MISSING" -eq 0 ] && [ "$CURRENT_VERSION" != "未安装" ]; then
    echo "[3/7] 当前版本已是最新 ($CURRENT_VERSION)，无需更新。跳过下载和替换。"
    echo "[4/7] 正在尝试重启服务..." # 即使不更新也尝试重启服务，确保服务运行
    sh "$STOP_SCRIPT"
    # 后台启动服务并重定向输出，避免阻塞
    nohup sh "$START_SCRIPT" >/dev/null 2>&1 &
    sleep 2 # 等待服务启动
    if pgrep -f "$MODDIR/watchdog.sh" >/dev/null || pgrep -f "$CLOUDFLARED_BIN" >/dev/null; then
        echo " -> 服务已成功在后台重启。"
    else
        echo " -> 服务重启失败，请检查日志或手动重启。"
    fi
    echo "======================"
    echo "更新流程全部完成。"
    exit 0
fi

echo "[3/7] 正在下载最新版本..."
DOWNLOAD_URL="${DOWNLOAD_BASE_URL}${ARCH}"
curl -L "$DOWNLOAD_URL" -o "$TEMP_FILE" --progress-bar
if [ ! -s "$TEMP_FILE" ]; then
    echo "错误: 下载失败或文件为空。请检查网络或下载链接。"
    rm -f "$TEMP_FILE"
    exit 1
fi
echo " -> 下载完成。"

echo "[4/7] 正在停止当前服务..."
sh "$STOP_SCRIPT"

echo "[5/7] 正在替换文件并设置权限..."
mv "$TEMP_FILE" "$CLOUDFLARED_BIN"
chmod +x "$CLOUDFLARED_BIN"
echo " -> 文件已更新。"

echo "[6/7] 正在校验新版本..."
NEW_VERSION_OUTPUT=$("$CLOUDFLARED_BIN" --version 2>/dev/null | head -n 1)
NEW_VERSION="无法获取"
if echo "$NEW_VERSION_OUTPUT" | grep -q "version"; then
    PARSED_NEW_VERSION=$(echo "$NEW_VERSION_OUTPUT" | awk '{print $3}' | sed 's/(build//g' | sed 's/)//g' | sed 's/\r//g')
    if echo "$PARSED_NEW_VERSION" | grep -q "UTC"; then
        PARSED_NEW_VERSION=$(echo "$NEW_VERSION_OUTPUT" | awk '{print $(NF-2)}' | sed 's/(build//g' | sed 's/)//g' | sed 's/\r//g')
    fi
    PARSED_NEW_VERSION=$(echo "$PARSED_NEW_VERSION" | sed 's/(build.*//' | sed 's/\r//g')
    
    if [ -n "$PARSED_NEW_VERSION" ] && ! echo "$PARSED_NEW_VERSION" | grep -q "无法获取"; then
        NEW_VERSION="$PARSED_NEW_VERSION"
    fi
fi

# 更新本地版本号文件
echo "$NEW_VERSION" > "$VERSION_FILE"

echo " -> 更新成功！"
echo "    旧版本: $CURRENT_VERSION"
echo "    新版本: $NEW_VERSION"

echo "[7/7] 正在尝试重启服务..."
nohup sh "$START_SCRIPT" >/dev/null 2>&1 &
sleep 2 # 等待服务启动
if pgrep -f "$MODDIR/watchdog.sh" >/dev/null || pgrep -f "$CLOUDFLARED_BIN" >/dev/null; then
    echo " -> 服务已成功在后台重启。"
else
    echo " -> 服务重启失败，请检查日志或手动重启。"
fi

echo "======================"
echo "更新流程全部完成。"
exit 0