#!/system/bin/sh
# v2.0: Re-structured directories

echo " "
echo "**************************************"
echo "* 正在卸载 Cloudflared Tunnel 模块  *"
echo "**************************************"
echo " "

echo "- 正在停止所有相关服务..."
# $MODPATH 是 Magisk 在执行此脚本时提供的环境变量，指向模块根目录
pkill -f "$MODPATH/watchdog.sh" || true
pkill -f "$MODPATH/core/cloudflared tunnel" || true
pkill -f "dnsmasq --listen-address=127.0.0.1,::1" || true
echo "  -> 所有服务已停止。"
echo " "

echo "-> 清理完成。请重启手机。"
echo " "